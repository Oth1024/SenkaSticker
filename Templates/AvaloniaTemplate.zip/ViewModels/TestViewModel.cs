using Avalonia;
using Avalonia.Interactivity;
using Avalonia.Styling;

namespace $rootnamespace$.ViewModels;

public class $fileinputname$ViewModel : ViewModelBase
{
    #region Constructor
    public $fileinputname$ViewModel()
    {

    }
    #endregion
        
    #region Events
    #endregion
        
    #region Fields
    #endregion
    
    
    #region Properties
    #endregion
    
    #region Methods
    #endregion
}
