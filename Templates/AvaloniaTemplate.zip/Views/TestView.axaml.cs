using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using Avalonia.Styling;

namespace $rootnamespace$.Views;

public partial class $fileinputname$View : UserControl
{
    public $fileinputname$View()
    {
        InitializeComponent();
    }
}