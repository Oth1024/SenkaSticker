﻿using System;
using System.Collections;
using System.Threading;
using System.Linq;

namespace $rootnamespace$;

public class $safeitemname$
{
    #region Constructor
    #endregion

    #region Events
    #endregion

    #region Fields
    #endregion

    #region Properties
    #endregion

    #region Methods
    #endregion
}
